from pathlib import Path
import json,os,subprocess,time,sys
sys.path.insert(0,str(Path(__file__).parent));import proton_accept as harness
harness.require_locks('m74','sweep-W7-1399');work=Path('/tmp/w7m5');result={'operationId':'1eb49f84-4013-4949-b5fa-d83cca7b87bd','historyId':'2565ce6e-45cb-4f6c-82f3-fe077edf1730','actions':[]}
app=harness.App.__new__(harness.App);app.root=Path('/');app.work=work;app.launcher=Path('/usr/bin/putgd-launcher');app.entries=[];_,session=harness.desktop_environment();env={k:os.environ[k] for k in ('HOME','USER','PATH','LANG') if k in os.environ};env.update(session)
env.update({f'XDG_{key}_HOME':str(work/'profile'/name) for key,name in [('CONFIG','config'),('DATA','data'),('STATE','state'),('CACHE','cache')]});env['XDG_RUNTIME_DIR']=str(work/'profile/runtime');env['TMPDIR']=str(work);app.environment=env;app.cli_environment=env
socket=str(work/'profile/runtime/putgd/session.sock');assert len(socket.encode())<=107
assert app.call('capabilities',timeout=10)[1] is not None
app.process=subprocess.Popen(['/usr/bin/putgd-launcher','--background'],env=env,stdin=subprocess.DEVNULL,stdout=(work/'recovery-resident.log').open('x'),stderr=subprocess.STDOUT,start_new_session=True)
try:
 until=time.monotonic()+60
 while app.call('capabilities',timeout=10)[1] is not None:
  assert time.monotonic()<until;time.sleep(.2)
 time.sleep(6)
 detail=app.need('history.detail',{'id':result['historyId']});result['before']={k:detail.get(k) for k in ('uploadStatus','shareStatus','linkAvailable')}
 for method in ('history.inspectLink','history.revokeLink'):
  if method.endswith('revokeLink') and result['actions'][-1].get('status')!='shared':break
  answer,error=app.call(method,{'id':result['historyId']})
  if error:result['actions'].append({'method':method,'refused':error['code']});break
  until=time.monotonic()+120
  while True:
   state=app.need('share.inspect',{'id':answer['shareOperationId']})
   if state.get('status',state.get('state')) not in ('pending','running'):break
   assert time.monotonic()<until;time.sleep(.2)
  result['actions'].append({'method':method,'shareOperationId':answer['shareOperationId'],'status':state.get('status'),'error':(state.get('error') or {}).get('code')})
 result['helpersGoneAfter']=harness.helpers_gone(40)
finally:
 app.stop();(work/'recovery.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
