import os,json,subprocess,time
from pathlib import Path
P=Path.home()/'work/sfa15';root=Path.home()/'work/scroll-tracker/runs/final15'
# These 160 lists include the recorded and derived (reverse/splice/down-up) sequences.
used={Path(l).parent for f in root.glob('*/list.txt') for l in f.read_text().splitlines() if l.strip()}
corpus=Path.home()/'work/scroll-tracker/corpus3'
raw=sorted({p.parent for p in corpus.rglob('[0-9][0-9][0-9][0-9].png')}-used)
lists=P/'extra-lists';lists.mkdir()
seq=[]
for d in raw:
 f=lists/('_'.join(d.relative_to(corpus).parts)+'.txt');f.write_text('\n'.join(str(x) for x in sorted(d.glob('[0-9][0-9][0-9][0-9].png')))+'\n');seq.append(f)
print('extra corpus sequences',len(seq),flush=True)
out=P/'replay-extra';out.mkdir(); results=[]
for i,src in enumerate(seq):
 d=out/src.stem;d.mkdir()
 t=time.time()
 with (d/'stdout.log').open('w') as o,(d/'stderr.log').open('w') as e:
  p=subprocess.run([str(P/'repo/build/asan/test_scroll_tracker_replay'),'--list',str(src),'--out',str(d),'--max-height','60000'],stdout=o,stderr=e,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='print_stacktrace=1:halt_on_error=1'))
 r={'sequence':src.stem,'exit':p.returncode,'seconds':round(time.time()-t,2),'stderrBytes':(d/'stderr.log').stat().st_size};results.append(r)
 (P/'replay-extra-summary.json').write_text(json.dumps(results,indent=1));print(i+1,r,flush=True)
