from pathlib import Path
import xml.etree.ElementTree as ET, statistics, json,csv
root=Path.home()/'work/wf1108'
allrows={}
for phase in ('before','after'):
 rows=[]
 for p in (root/phase).glob('*.xml'):
  tree=ET.parse(p).getroot()
  for fn in tree.findall('TestFunction'):
   name=fn.attrib['name']
   if name in ('initTestCase','cleanupTestCase'):continue
   dur=float(fn.find('Duration').attrib['msecs'])
   tags=sorted({tag.text or '' for tag in fn.findall('.//DataTag')})
   incidents=fn.findall('Incident');assert all(x.attrib['type']=='pass' for x in incidents),(p,name)
   rows.append(dict(name=name,ms=dur,tags=tags,file=p.name))
 allrows[phase]=rows
from collections import Counter
for phase,rows in allrows.items():
 assert set(Counter(r['name'] for r in rows).values()) == {6}, phase
before={(r['name'],tuple(r['tags'])) for r in allrows['before']};after={(r['name'],tuple(r['tags'])) for r in allrows['after']};assert before==after,(before-after,after-before)
with (root/'function-timings.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['function','before_median_ms','after_median_ms','data_tags'])
 for name,tags in sorted(before):
  w.writerow([name,*[round(statistics.median(r['ms'] for r in allrows[phase] if r['name']==name),3) for phase in ('before','after')],' | '.join(tags)])
summary={'functions':len(before),'tagged_rows':sum(len(t) if t else 1 for n,t in before),'inventories_equal':True}
for phase in ('before','after'):
 runs=json.loads((root/phase/'result.json').read_text());assert all(r['exit']==0 for r in runs);summary[phase]=runs
(root/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
