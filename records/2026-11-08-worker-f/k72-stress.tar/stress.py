import os,pathlib,subprocess,json
root=pathlib.Path.home()/'work/wf1108';out=root/'stress';out.mkdir(mode=0o700)
env=os.environ.copy();env.update(QT_QPA_PLATFORM='offscreen',TMPDIR=str(out),XDG_RUNTIME_DIR=str(out))
subprocess.run(['python3',str(root/'tools/diagnostics/check_socket_paths.py'),'--socket',str(out/'putgd/session.sock')],check=True)
results=[]
for i in range(50):
 with (out/f'{i}.log').open('w') as f:
  p=subprocess.run([str(root/'build/dev/test_gui_settings_advanced'),'copiedDiagnosticsPreserveExactPathsAndRevisions'],env=env,stdout=f,stderr=subprocess.STDOUT)
 results.append(p.returncode)
 if p.returncode: break
(out/'result.json').write_text(json.dumps(results));print(results)
