import os,subprocess,pathlib,concurrent.futures,json,time
root=pathlib.Path.home()/'work/wf1108'
phase=__import__('sys').argv[1]
out=root/phase;out.mkdir(mode=0o700)
def run(i):
 runtime=out/f'r{i}';runtime.mkdir(mode=0o700)
 sock=runtime/'putgd/session.sock'
 subprocess.run(['python3',str(root/'tools/diagnostics/check_socket_paths.py'),'--socket',str(sock)],check=True)
 env=os.environ.copy();env.update(QT_QPA_PLATFORM='offscreen:configfile='+str(root/'tests/fixtures/offscreen-one-monitor.json'),XDG_RUNTIME_DIR=str(runtime),TMPDIR=str(runtime),PUTGD_TEST_TIME_SCALE='1')
 start=time.monotonic()
 with (out/f'{i}.log').open('w') as f:
  p=subprocess.run([str(root/'build/dev/test_review_window'),'-o',str(out/f'{i}.xml')+',xml'],env=env,stdout=f,stderr=subprocess.STDOUT)
 return dict(slot=i,exit=p.returncode,seconds=time.monotonic()-start)
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex:
 result=list(ex.map(run,range(6)))
(out/'result.json').write_text(json.dumps(result,indent=2));print(result)
