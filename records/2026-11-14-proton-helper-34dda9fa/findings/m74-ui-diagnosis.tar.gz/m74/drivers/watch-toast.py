from pathlib import Path
import os,sys,subprocess,selectors,time,json,re
sys.path.insert(0,str(Path.home()/'work/w7-34'))
from proton_accept import desktop_environment
work=Path.home()/'work/w7-34';env=dict(os.environ);env.update(desktop_environment()[1]);p=subprocess.Popen(['dbus-monitor',"type='method_call',interface='org.freedesktop.Notifications',member='Notify'"],env=env,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,text=True,bufsize=1)
(work/'toast-monitor-pid.json').write_text(json.dumps({'pid':p.pid,'startedUtc':time.time(),'scope':'Only the exact known generic UI error text, message header and sender PID are retained; other notification bodies are not written.'}))
sel=selectors.DefaultSelector();sel.register(p.stdout,selectors.EVENT_READ);header='';end=time.monotonic()+240
with (work/'toast-dbus.jsonl').open('w') as f:
 try:
  while time.monotonic()<end:
   if not sel.select(1):continue
   line=p.stdout.readline()
   if not line:break
   if line.startswith('method call '):header=line.strip()
   if 'The window could not be opened. Try opening it again from the tray.' in line:
    match=re.search(r'sender=([^ ]+)',header);sender=match[1] if match else ''
    pid=subprocess.run(['dbus-send','--session','--print-reply','--dest=org.freedesktop.DBus','/org/freedesktop/DBus','org.freedesktop.DBus.GetConnectionUnixProcessID','string:'+sender],env=env,capture_output=True,text=True).stdout
    f.write(json.dumps({'utc':time.time(),'header':header,'senderPidReply':pid,'exactKnownMessage':True})+'\n');f.flush()
 finally:
  p.terminate();p.wait(timeout=5);sel.close()
