from pathlib import Path
import time,json
p=Path("/tmp/w34m6/history.png");end=time.monotonic()+360
while time.monotonic()<end:
 if p.exists():
  raw=p.read_bytes()
  if raw.endswith(bytes.fromhex("0000000049454e44ae426082")):
   p.with_name("history-before-close.png").write_bytes(raw);p.with_name("frame-retention.json").write_text(json.dumps({"utc":time.time(),"source":"first complete history.png before later diagnostic teardown screenshot"})+"\n");break
 time.sleep(.005)
