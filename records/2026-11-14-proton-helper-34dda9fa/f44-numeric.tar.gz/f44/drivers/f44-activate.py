import os,sys,json,subprocess,hashlib
from pathlib import Path
sys.path.insert(0,str(Path.home()/'work/w7-34'))
from proton_accept import desktop_environment
work=Path.home()/'work/w7-34';e=dict(os.environ);e.update(desktop_environment()[1])
def c(args):return subprocess.run(args,env=e,text=True,capture_output=True)
helper=Path('/usr/libexec/putgd/proton/putgd-proton-runtime');assert hashlib.sha256(helper.read_bytes()).hexdigest()=='34dda9fa8550029058b84b95f3a8bbb97f8c377fdd68007bfedf5d4dab21c09b'
for action in ('disable','enable'):
 x=c(['gnome-extensions',action,'putgd@put.gd']);print(action,x.returncode,x.stdout,x.stderr)
x=c(['gnome-extensions','info','putgd@put.gd']);print(x.stdout);(work/'gnome-active.json').write_text(json.dumps({'info':x.stdout,'exitCode':x.returncode},indent=2)+'\n')
(work/'environment.json').write_text(json.dumps({'kernel':os.uname().release,'clockTicks':os.sysconf('SC_CLK_TCK'),'logicalCpus':os.cpu_count(),'packageVersions':c(['rpm','-q','putgd','gnome-shell','qt6-qtbase']).stdout},indent=2)+'\n')
