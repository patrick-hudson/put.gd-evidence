from pathlib import Path
import os,sys,json,subprocess
sys.path.insert(0,str(Path.home()/'work/w7-34'))
from proton_accept import desktop_environment,helper_pids
assert not helper_pids()
work=Path.home()/'work/w7-34';before=json.loads((work/'gnome-before.json').read_text());env=dict(os.environ);env.update(desktop_environment()[1])
def c(a):return subprocess.run(a,env=env,capture_output=True,text=True)
assert c(['pgrep','-x','putgd']).returncode==1
c(['gnome-extensions','disable','putgd@put.gd'])
for key in ('enabled-extensions','disable-user-extensions'):
 subprocess.run(['gsettings','set','org.gnome.shell',key,before[key]],env=env,check=True)
after={k:c(['gsettings','get','org.gnome.shell',k]).stdout.strip() for k in ('enabled-extensions','disable-user-extensions')};assert all(after[k]==before[k] for k in after)
r=c(['gnome-extensions','info','putgd@put.gd']);after.update(extensionInfoExitCode=r.returncode,extensionInfo=r.stdout,installedPackage=c(['rpm','-q','putgd']).stdout.strip());(work/'gnome-after.json').write_text(json.dumps(after,indent=2)+'\n');(work/'package-after.txt').write_text(after['installedPackage']+'\n');print(json.dumps(after,indent=2))
