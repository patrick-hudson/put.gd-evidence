import os,sys,json,subprocess,hashlib
from pathlib import Path
sys.path.insert(0,str(Path.home()/'work/w7-34'))
from proton_accept import desktop_environment
work=Path.home()/'work/w7-34';e=dict(os.environ);e.update(desktop_environment()[1])
for name in ('gnome-before.json','package-before.txt'):
 p=work/name
 if p.exists():p.rename(work/(name+'.trial'))
def c(args):return subprocess.run(args,env=e,text=True,capture_output=True)
r={k:c(['gsettings','get','org.gnome.shell',k]).stdout.strip() for k in ('enabled-extensions','disable-user-extensions')};i=c(['gnome-extensions','info','putgd@put.gd']);r.update(extensionInfoExitCode=i.returncode,extensionInfo=i.stdout)
(work/'gnome-before.json').write_text(json.dumps(r,indent=2)+'\n');(work/'package-before.txt').write_text(c(['rpm','-q','putgd']).stdout)
with (work/'install.log').open('w') as f:
 subprocess.run(['sudo','-n','dnf','-y','--setopt=install_weak_deps=False','install',str(next(work.glob('*.rpm')))],stdout=f,stderr=subprocess.STDOUT,check=True)
helper=Path('/usr/lib/putgd/proton/putgd-proton-runtime');assert hashlib.sha256(helper.read_bytes()).hexdigest()=='34dda9fa8550029058b84b95f3a8bbb97f8c377fdd68007bfedf5d4dab21c09b'
for action in ('disable','enable'):
 x=c(['gnome-extensions',action,'putgd@put.gd']);print(action,x.returncode,x.stdout,x.stderr)
x=c(['gnome-extensions','info','putgd@put.gd']);print(x.stdout);(work/'gnome-active.json').write_text(json.dumps({'info':x.stdout,'exitCode':x.returncode},indent=2)+'\n')
(work/'environment.json').write_text(json.dumps({'kernel':os.uname().release,'clockTicks':os.sysconf('SC_CLK_TCK'),'logicalCpus':os.cpu_count(),'packageVersions':c(['rpm','-q','putgd','gnome-shell','qt6-qtbase']).stdout},indent=2)+'\n')
